CREATE DATABASE Pokemon;

USE Pokemon;

-- Create a table that stores all regions
CREATE TABLE Region(
                       region_id INT PRIMARY KEY AUTO_INCREMENT,
                       name VARCHAR(50) NOT NULL,
                       climate VARCHAR(50) NOT NULL
);

-- Create a table that stores data on towns across the world
CREATE TABLE Town(
                     town_id INT PRIMARY KEY AUTO_INCREMENT,
                     region_id INT NOT NULL,
                     name VARCHAR(50) NOT NULL,
                     population INT NOT NULL,
                     FOREIGN KEY(region_id) REFERENCES Region(region_id)
);

-- Create a table that stores all types
CREATE TABLE Types(
                      type_id INT PRIMARY KEY AUTO_INCREMENT,
                      type_name VARCHAR(50) NOT NULL
);

-- Create a table that stores data on Trainers
CREATE TABLE Trainer(
                        trainer_id INT PRIMARY KEY AUTO_INCREMENT,
                        home_town_id INT NOT NULL,
                        name VARCHAR(50) NOT NULL,
                        gender VARCHAR(50) NOT NULL,
                        age INT,
                        FOREIGN KEY(home_town_id) REFERENCES Town(town_id)
);

-- Create a table that stores general data on pokemon species
CREATE TABLE Pokemon(
                        pokemon_id INT PRIMARY KEY AUTO_INCREMENT,
                        name VARCHAR(50) NOT NULL,
                        base_hp INT NOT NULL,
                        base_attack INT NOT NULL,
                        base_defense INT NOT NULL
);

-- Create a table that has a compound key and stores data on types each pokemon has
CREATE TABLE PokemonTypes(
                             pokemon_id INT NOT NULL,
                             type_id INT NOT NULL,
                             PRIMARY KEY(pokemon_id, type_id),
                             FOREIGN KEY(pokemon_id) REFERENCES Pokemon(pokemon_id),
                             FOREIGN KEY(type_id) REFERENCES Types(type_id)
);

-- Create a table that stores data on each pokemon owned by a trainer
CREATE TABLE TrainerPokemon(
                               caught_id INT PRIMARY KEY AUTO_INCREMENT,
                               trainer_id INT NOT NULL,
                               pokemon_id INT NOT NULL,
                               nick_name VARCHAR(50) NOT NULL,
                               pokemon_level INT NOT NULL,
                               hit_points_iv INT NOT NULL,
                               attack_iv INT NOT NULL,
                               defense_iv INT NOT NULL,
                               FOREIGN KEY(trainer_id) REFERENCES Trainer(trainer_id),
                               FOREIGN KEY(pokemon_id) REFERENCES Pokemon(pokemon_id)
);

-- Create a table that has information on badges in the gyms
CREATE TABLE Badge(
                      badge_id INT PRIMARY KEY AUTO_INCREMENT,
                      badge_name VARCHAR(50) NOT NULL
);

-- Create a table that has information on Gyms
CREATE TABLE Gym(
                    gym_id INT PRIMARY KEY AUTO_INCREMENT,
                    leader_id INT NOT NULL,
                    town_id INT NOT NULL,
                    type_id INT NOT NULL,
                    badge_id INT NOT NULL,
                    FOREIGN KEY(leader_id) REFERENCES Trainer(trainer_id),
                    FOREIGN KEY(town_id) REFERENCES Town(town_id),
                    FOREIGN KEY(type_id) REFERENCES Types(type_id),
                    FOREIGN KEY(badge_id) REFERENCES Badge(badge_id)
);

-- Create a table that stores all type advantages
CREATE TABLE TypeAdvantage(
                              type_1 INT NOT NULL,
                              type_2 INT NOT NULL,
                              type_advantage VARCHAR(50) NOT NULL,
                              PRIMARY KEY(type_1, type_2),
                              FOREIGN KEY(type_1) REFERENCES Types(type_id),
                              FOREIGN KEY(type_2) REFERENCES Types(type_id)
);

-- Create a table that stores information on wild pokemon appearances and level range
CREATE TABLE WildPokemon(
                            wild_id INT PRIMARY KEY AUTO_INCREMENT,
                            pokemon_id INT NOT NULL,
                            region_id INT NOT NULL,
                            location_description VARCHAR(50) NOT NULL,
                            min_level INT NOT NULL,
                            max_level INT NOT NULL,
                            FOREIGN KEY(pokemon_id) REFERENCES Pokemon(pokemon_id),
                            FOREIGN KEY(region_id) REFERENCES Region(region_id)
);

-- Insert data into Region
INSERT INTO Region (region_id, name, climate) VALUES
                                                  (1, "Kanto", "Humid subtropical climate"),
                                                  (2, "Johto", "Humid subtropical climate"),
                                                  (3, "Hoenn", "Tropical rainforest climate"),
                                                  (4, "Sonnoh", "Warm-summer humid continental"),
                                                  (5, "Unova", "Hot-summer humid continental"),
                                                  (6, "Kalos", "Oceanic"),
                                                  (7, "Alola", "Hot semi-arid"),
                                                  (8, "Galar", "Oceanic"),
                                                  (9, "Hisui", "Warm-summer humid continental"),
                                                  (10, "Paldea", "Humid subtropical climate");
-- Insert data into Town
INSERT INTO Town (town_id, region_id, name, population) VALUES
                                                            (1, 1, "Pewter City", 30),
                                                            (2, 1, "Cerulean City", 27),
                                                            (3, 1, "Vermilion City", 25),
                                                            (4, 2, "Violet City", 52),
                                                            (5, 3, "Littleroot Town", 10),
                                                            (6, 3, "Oldale Town", 14),
                                                            (7, 4, "Twinleaf Town", 10),
                                                            (8, 4, "Sandgem Town", 25),
                                                            (9, 5, "Castelia City", 137),
                                                            (10, 5, "Nimbasa City", 239),
                                                            (11, 6, "Lumiose City", 448),
                                                            (12, 6, "Camphrier Town", 17),
                                                            (13, 7, "HeaHea City", 82),
                                                            (14, 7, "Malie City", 84),
                                                            (15, 8, "Hulbury", 54),
                                                            (16, 8, "Motostoke", 120),
                                                            (17, 9, "Jubilife Village", 102),
                                                            (18, 9, "Diamond Outpost", 19),
                                                            (19, 10, "Mesagoza", 756),
                                                            (20, 10, "Medali", 95);
-- Insert data into Types
INSERT INTO Types (type_id, type_name) VALUES
                                           (1, "Normal"),
                                           (2, "Fire"),
                                           (3, "Fighting"),
                                           (4, "Water"),
                                           (5, "Flying"),
                                           (6, "Grass"),
                                           (7, "Poison"),
                                           (8, "Electric"),
                                           (9, "Ground"),
                                           (10, "Psychic"),
                                           (11, "Rock"),
                                           (12, "Ice"),
                                           (13, "Bug"),
                                           (14, "Dragon"),
                                           (15, "Ghost"),
                                           (16, "Dark"),
                                           (17, "Steel"),
                                           (18, "Fairy");
-- Insert data into Trainer
INSERT INTO Trainer (trainer_id, home_town_id, name, gender, age) VALUES
                                                                      (1, 1, "Brock", "M", 15),
                                                                      (2, 2, "Misty", "F", 10),
                                                                      (3, 3, "Surge", "M", 34),
                                                                      (4, 4, "Josh", "M", 12),
                                                                      (5, 5, "Jane", "F", 75),
                                                                      (6, 6, "Lux", "F", 12),
                                                                      (7, 7, "Ash", "M", 64),
                                                                      (8, 8, "Riven", "F", 45),
                                                                      (9, 9, "Kael", "M", 22),
                                                                      (10, 10, "Mira", "F", 26);
-- Insert data into Pokemon
INSERT INTO Pokemon (pokemon_id, name, base_hp, base_attack, base_defense) VALUES
                                                                               (1, "Bulbasaur", 45, 49, 49),
                                                                               (2, "Ivysaur", 60, 62, 63),
                                                                               (3, "Venusaur", 80, 82, 83),
                                                                               (4, "Charmander", 39, 52, 43),
                                                                               (5, "Charmeleon", 58, 64, 58),
                                                                               (6, "Charizard", 78, 84, 78),
                                                                               (7, "Squirtle", 44, 48, 65),
                                                                               (8, "Wartortle", 59, 63, 80),
                                                                               (9, "Blastoise", 79, 83, 100),
                                                                               (10, "Caterpie", 45, 30, 35),
                                                                               (11, "Metapod", 50, 20, 55),
                                                                               (12, "Butterfree", 60, 45, 50),
                                                                               (13, "Weedle", 40, 35, 30),
                                                                               (14, "Kakuna", 45, 25, 50),
                                                                               (15, "Beedrill", 65, 90, 40),
                                                                               (16, "Pidgey", 40, 45, 40),
                                                                               (17, "Pidgeotto", 63, 60, 55),
                                                                               (18, "Pidgeot", 83, 80, 75),
                                                                               (19, "Rattata", 30, 56, 35),
                                                                               (20, "Raticate", 55, 81, 60),
                                                                               (21, "Spearow", 40, 60, 30),
                                                                               (22, "Fearow", 65, 90, 65),
                                                                               (23, "Ekans", 35, 60, 44),
                                                                               (24, "Arbok", 60, 85, 69),
                                                                               (25, "Pikachu", 35, 55, 40),
                                                                               (26, "Raichu", 60, 90, 55),
                                                                               (27, "Sandshrew", 50, 75, 85),
                                                                               (28, "Sandslash", 75, 100, 110),
                                                                               (29, "Nidoran♀", 55, 47, 52),
                                                                               (30, "Nidorina", 70, 62, 67),
                                                                               (31, "Nidoqueen", 90, 92, 87),
                                                                               (32, "Nidoran♂", 46, 57, 40),
                                                                               (33, "Nidorino", 61, 72, 57),
                                                                               (34, "Nidoking", 81, 102, 77),
                                                                               (35, "Clefairy", 70, 45, 48),
                                                                               (36, "Clefable", 95, 70, 73),
                                                                               (37, "Vulpix", 38, 41, 40),
                                                                               (38, "Ninetales", 73, 76, 75),
                                                                               (39, "Jigglypuff", 115, 45, 20),
                                                                               (40, "Wigglytuff", 140, 70, 45),
                                                                               (41, "Zubat", 40, 45, 35),
                                                                               (42, "Golbat", 75, 80, 70),
                                                                               (43, "Oddish", 45, 50, 55),
                                                                               (44, "Gloom", 60, 65, 70),
                                                                               (45, "Vileplume", 75, 80, 85),
                                                                               (46, "Paras", 35, 70, 55),
                                                                               (47, "Parasect", 60, 95, 80),
                                                                               (48, "Venonat", 60, 55, 50),
                                                                               (49, "Venomoth", 70, 65, 60),
                                                                               (50, "Diglett", 10, 55, 25),
                                                                               (51, "Dugtrio", 35, 80, 50),
                                                                               (52, "Meowth", 40, 45, 35),
                                                                               (53, "Persian", 65, 70, 60),
                                                                               (54, "Psyduck", 50, 52, 48),
                                                                               (55, "Golduck", 80, 82, 78),
                                                                               (56, "Mankey", 40, 80, 35),
                                                                               (57, "Primeape", 65, 105, 60),
                                                                               (58, "Growlithe", 55, 70, 45),
                                                                               (59, "Arcanine", 90, 110, 80),
                                                                               (60, "Poliwag", 40, 50, 40),
                                                                               (61, "Poliwhirl", 65, 65, 65),
                                                                               (62, "Poliwrath", 90, 95, 95),
                                                                               (63, "Abra", 25, 20, 15),
                                                                               (64, "Kadabra", 40, 35, 30),
                                                                               (65, "Alakazam", 55, 50, 45),
                                                                               (66, "Machop", 70, 80, 50),
                                                                               (67, "Machoke", 80, 100, 70),
                                                                               (68, "Machamp", 90, 130, 80),
                                                                               (69, "Bellsprout", 50, 75, 35),
                                                                               (70, "Weepinbell", 65, 90, 50),
                                                                               (71, "Victreebel", 80, 105, 65),
                                                                               (72, "Tentacool", 40, 40, 35),
                                                                               (73, "Tentacruel", 80, 70, 65),
                                                                               (74, "Geodude", 40, 80, 100),
                                                                               (75, "Graveler", 55, 95, 115),
                                                                               (76, "Golem", 80, 120, 130),
                                                                               (77, "Ponyta", 50, 85, 55),
                                                                               (78, "Rapidash", 65, 100, 70),
                                                                               (79, "Slowpoke", 90, 65, 65),
                                                                               (80, "Slowbro", 95, 75, 110),
                                                                               (81, "Magnemite", 25, 35, 70),
                                                                               (82, "Magneton", 50, 60, 95),
                                                                               (83, "Farfetch’d", 52, 65, 55),
                                                                               (84, "Doduo", 35, 85, 45),
                                                                               (85, "Dodrio", 60, 110, 70),
                                                                               (86, "Seel", 65, 45, 55),
                                                                               (87, "Dewgong", 90, 70, 80),
                                                                               (88, "Grimer", 80, 80, 50),
                                                                               (89, "Muk", 105, 105, 75),
                                                                               (90, "Shellder", 30, 65, 100),
                                                                               (91, "Cloyster", 50, 95, 180),
                                                                               (92, "Gastly", 30, 35, 30),
                                                                               (93, "Haunter", 45, 50, 45),
                                                                               (94, "Gengar", 60, 65, 60),
                                                                               (95, "Onix", 35, 45, 160),
                                                                               (96, "Drowzee", 60, 48, 45),
                                                                               (97, "Hypno", 85, 73, 70),
                                                                               (98, "Krabby", 30, 105, 90),
                                                                               (99, "Kingler", 55, 130, 115),
                                                                               (100, "Voltorb", 40, 30, 50),
                                                                               (101, "Electrode", 60, 50, 70),
                                                                               (102, "Exeggcute", 60, 40, 80),
                                                                               (103, "Exeggutor", 95, 95, 85),
                                                                               (104, "Cubone", 50, 50, 95),
                                                                               (105, "Marowak", 60, 80, 110),
                                                                               (106, "Hitmonlee", 50, 120, 53),
                                                                               (107, "Hitmonchan", 50, 105, 79),
                                                                               (108, "Lickitung", 90, 55, 75),
                                                                               (109, "Koffing", 40, 65, 95),
                                                                               (110, "Weezing", 65, 90, 120),
                                                                               (111, "Rhyhorn", 80, 85, 95),
                                                                               (112, "Rhydon", 105, 130, 120),
                                                                               (113, "Chansey", 250, 5, 5),
                                                                               (114, "Tangela", 65, 55, 115),
                                                                               (115, "Kangaskhan", 105, 95, 80),
                                                                               (116, "Horsea", 30, 40, 70),
                                                                               (117, "Seadra", 55, 65, 95),
                                                                               (118, "Goldeen", 45, 67, 60),
                                                                               (119, "Seaking", 80, 92, 65),
                                                                               (120, "Staryu", 30, 45, 55),
                                                                               (121, "Starmie", 60, 75, 85),
                                                                               (122, "Mr. Mime", 40, 45, 65),
                                                                               (123, "Scyther", 70, 110, 80),
                                                                               (124, "Jynx", 65, 50, 35),
                                                                               (125, "Electabuzz", 65, 83, 57),
                                                                               (126, "Magmar", 65, 95, 57),
                                                                               (127, "Pinsir", 65, 125, 100),
                                                                               (128, "Tauros", 75, 100, 95),
                                                                               (129, "Magikarp", 20, 10, 55),
                                                                               (130, "Gyarados", 95, 125, 79),
                                                                               (131, "Lapras", 130, 85, 80),
                                                                               (132, "Ditto", 48, 48, 48),
                                                                               (133, "Eevee", 55, 55, 50),
                                                                               (134, "Vaporeon", 130, 65, 60),
                                                                               (135, "Jolteon", 65, 65, 60),
                                                                               (136, "Flareon", 65, 130, 60),
                                                                               (137, "Porygon", 65, 60, 70),
                                                                               (138, "Omanyte", 35, 40, 100),
                                                                               (139, "Omastar", 70, 60, 125),
                                                                               (140, "Kabuto", 30, 80, 90),
                                                                               (141, "Kabutops", 60, 115, 105),
                                                                               (142, "Aerodactyl", 80, 105, 65),
                                                                               (143, "Snorlax", 160, 110, 65),
                                                                               (144, "Articuno", 90, 85, 100),
                                                                               (145, "Zapdos", 90, 90, 85),
                                                                               (146, "Moltres", 90, 100, 90),
                                                                               (147, "Dratini", 41, 64, 45),
                                                                               (148, "Dragonair", 61, 84, 65),
                                                                               (149, "Dragonite", 91, 134, 95),
                                                                               (150, "Mewtwo", 106, 110, 90),
                                                                               (151, "Mew", 100, 100, 100);
-- Insert data into PokemonTypes
INSERT INTO PokemonTypes (pokemon_id, type_id) VALUES
                                                   (1, 6),
                                                   (1, 7),
                                                   (2, 6),
                                                   (2, 7),
                                                   (3, 6),
                                                   (3, 7),
                                                   (4, 2),
                                                   (5, 2),
                                                   (6, 2),
                                                   (6, 5),
                                                   (7, 4),
                                                   (8, 4),
                                                   (9, 4),
                                                   (10, 13),
                                                   (11, 13),
                                                   (12, 13),
                                                   (12, 5),
                                                   (13, 13),
                                                   (13, 7),
                                                   (14, 13),
                                                   (14, 7),
                                                   (15, 13),
                                                   (15, 7),
                                                   (16, 1),
                                                   (16, 5),
                                                   (17, 1),
                                                   (17, 5),
                                                   (18, 1),
                                                   (18, 5),
                                                   (19, 1),
                                                   (20, 1),
                                                   (21, 1),
                                                   (21, 5),
                                                   (22, 1),
                                                   (22, 5),
                                                   (23, 7),
                                                   (24, 7),
                                                   (25, 8),
                                                   (26, 8),
                                                   (27, 9),
                                                   (28, 9),
                                                   (29, 7),
                                                   (30, 7),
                                                   (31, 7),
                                                   (31, 9),
                                                   (32, 7),
                                                   (33, 7),
                                                   (34, 7),
                                                   (34, 9),
                                                   (35, 1),
                                                   (36, 1),
                                                   (37, 2),
                                                   (38, 2),
                                                   (39, 1),
                                                   (40, 1),
                                                   (41, 7),
                                                   (41, 5),
                                                   (42, 7),
                                                   (42, 5),
                                                   (43, 6),
                                                   (43, 7),
                                                   (44, 6),
                                                   (44, 7),
                                                   (45, 6),
                                                   (45, 7),
                                                   (46, 13),
                                                   (46, 6),
                                                   (47, 13),
                                                   (47, 6),
                                                   (48, 13),
                                                   (48, 7),
                                                   (49, 13),
                                                   (49, 7),
                                                   (50, 9),
                                                   (51, 9),
                                                   (52, 1),
                                                   (53, 1),
                                                   (54, 4),
                                                   (55, 4),
                                                   (56, 3),
                                                   (57, 3),
                                                   (58, 2),
                                                   (59, 2),
                                                   (60, 4),
                                                   (61, 4),
                                                   (62, 4),
                                                   (62, 3),
                                                   (63, 10),
                                                   (64, 10),
                                                   (65, 10),
                                                   (66, 3),
                                                   (67, 3),
                                                   (68, 3),
                                                   (69, 6),
                                                   (69, 7),
                                                   (70, 6),
                                                   (70, 7),
                                                   (71, 6),
                                                   (71, 7),
                                                   (72, 4),
                                                   (72, 7),
                                                   (73, 4),
                                                   (73, 7),
                                                   (74, 11),
                                                   (74, 9),
                                                   (75, 11),
                                                   (75, 9),
                                                   (76, 11),
                                                   (76, 9),
                                                   (77, 2),
                                                   (78, 2),
                                                   (79, 4),
                                                   (79, 10),
                                                   (80, 4),
                                                   (80, 10),
                                                   (81, 8),
                                                   (82, 8),
                                                   (83, 1),
                                                   (83, 5),
                                                   (84, 1),
                                                   (84, 5),
                                                   (85, 1),
                                                   (85, 5),
                                                   (86, 4),
                                                   (87, 4),
                                                   (87, 12),
                                                   (88, 7),
                                                   (89, 7),
                                                   (90, 4),
                                                   (91, 4),
                                                   (91, 12),
                                                   (92, 15),
                                                   (92, 7),
                                                   (93, 15),
                                                   (93, 7),
                                                   (94, 15),
                                                   (94, 7),
                                                   (95, 11),
                                                   (95, 9),
                                                   (96, 10),
                                                   (97, 10),
                                                   (98, 4),
                                                   (99, 4),
                                                   (100, 8),
                                                   (101, 8),
                                                   (102, 6),
                                                   (102, 10),
                                                   (103, 6),
                                                   (103, 10),
                                                   (104, 9),
                                                   (105, 9),
                                                   (106, 3),
                                                   (107, 3),
                                                   (108, 1),
                                                   (109, 7),
                                                   (110, 7),
                                                   (111, 9),
                                                   (111, 11),
                                                   (112, 9),
                                                   (112, 11),
                                                   (113, 1),
                                                   (114, 6),
                                                   (115, 1),
                                                   (116, 4),
                                                   (117, 4),
                                                   (118, 4),
                                                   (119, 4),
                                                   (120, 4),
                                                   (121, 4),
                                                   (121, 10),
                                                   (122, 10),
                                                   (123, 13),
                                                   (123, 5),
                                                   (124, 12),
                                                   (124, 10),
                                                   (125, 8),
                                                   (126, 2),
                                                   (127, 13),
                                                   (128, 1),
                                                   (129, 4),
                                                   (130, 4),
                                                   (130, 5),
                                                   (131, 4),
                                                   (131, 12),
                                                   (132, 1),
                                                   (133, 1),
                                                   (134, 4),
                                                   (135, 8),
                                                   (136, 2),
                                                   (137, 1),
                                                   (138, 11),
                                                   (138, 4),
                                                   (139, 11),
                                                   (139, 4),
                                                   (140, 11),
                                                   (140, 4),
                                                   (141, 11),
                                                   (141, 4),
                                                   (142, 11),
                                                   (142, 5),
                                                   (143, 1),
                                                   (144, 12),
                                                   (144, 5),
                                                   (145, 8),
                                                   (145, 5),
                                                   (146, 2),
                                                   (146, 5),
                                                   (147, 14),
                                                   (148, 14),
                                                   (149, 14),
                                                   (149, 5),
                                                   (150, 10),
                                                   (151, 10);
-- Insert data into TrainerPokemon
INSERT INTO TrainerPokemon (caught_id, trainer_id, pokemon_id, nick_name, pokemon_level, hit_points_iv, attack_iv, defense_iv) VALUES
                                                                                                                                   (1, 1, 74, "Geodude", 12, 10, 10, 10),
                                                                                                                                   (2, 1, 95, "Onix", 14, 12, 12, 12),
                                                                                                                                   (3, 2, 120, "Staryu", 18, 20, 20, 20),
                                                                                                                                   (4, 2, 121, "Starmie", 21, 22, 22, 22),
                                                                                                                                   (5, 3, 100, "Voltorb", 21, 25, 25, 25),
                                                                                                                                   (6, 3, 25, "Pikachu", 18, 20, 20, 20),
                                                                                                                                   (7, 3, 26, "Raichu", 24, 24, 24, 24),
                                                                                                                                   (8, 4, 151, "Meow", 50, 30, 30, 30),
                                                                                                                                   (9, 4, 150, "MeowMeow", 50, 30, 30, 30),
                                                                                                                                   (10, 4, 146, "MoltenBird", 50, 30, 30, 30),
                                                                                                                                   (11, 4, 145, "ElectricBird", 50, 30, 30, 30),
                                                                                                                                   (12, 4, 144, "FrozenBird", 50, 30, 30, 30),
                                                                                                                                   (13, 5, 7, "Turtle", 10, 5, 5, 6),
                                                                                                                                   (14, 6, 1, "Bulb", 12, 3, 12, 12),
                                                                                                                                   (15, 7, 4, "Jeff", 13, 10, 5, 8),
                                                                                                                                   (16, 8, 35, "Fairy", 15, 8, 9, 10),
                                                                                                                                   (17, 10, 55, "Abrie", 25, 5, 11, 12),
                                                                                                                                   (18, 10, 65, "Allie", 35, 5, 13, 12),
                                                                                                                                   (19, 10, 71, "Victory", 30, 8, 6, 12),
                                                                                                                                   (20, 10, 68, "Macho", 40, 14, 10, 12);
-- Insert data into Badge
INSERT INTO Badge (badge_id, badge_name) VALUES
                                             (1, "Boulder Badge"),
                                             (2, "Water Badge"),
                                             (3, "Normal Badge");
-- Insert data into Gym
INSERT INTO Gym (gym_id, leader_id, town_id, type_id, badge_id) VALUES
                                                                    (1, 1, 1, 11, 1),
                                                                    (2, 2, 2, 4, 2),
                                                                    (3, 3, 3, 8, 3);
-- Insert data into TypeAdvantage
INSERT INTO TypeAdvantage (type_1, type_2, type_advantage) VALUES
                                                               (1, 1, "Normal"),
                                                               (1, 2, "Normal"),
                                                               (1, 3, "Normal"),
                                                               (1, 4, "Normal"),
                                                               (1, 5, "Normal"),
                                                               (1, 6, "Normal"),
                                                               (1, 7, "Normal"),
                                                               (1, 8, "Normal"),
                                                               (1, 9, "Normal"),
                                                               (1, 10, "Normal"),
                                                               (1, 11, "Not very effective"),
                                                               (1, 12, "Normal"),
                                                               (1, 13, "Normal"),
                                                               (1, 14, "Normal"),
                                                               (1, 15, "No effect"),
                                                               (1, 16, "Normal"),
                                                               (1, 17, "Not very effective"),
                                                               (1, 18, "Normal"),
                                                               (2, 1, "Normal"),
                                                               (2, 2, "Not very effective"),
                                                               (2, 3, "Normal"),
                                                               (2, 4, "Not very effective"),
                                                               (2, 5, "Normal"),
                                                               (2, 6, "Super effective"),
                                                               (2, 7, "Normal"),
                                                               (2, 8, "Normal"),
                                                               (2, 9, "Normal"),
                                                               (2, 10, "Normal"),
                                                               (2, 11, "Not very effective"),
                                                               (2, 12, "Super effective"),
                                                               (2, 13, "Super effective"),
                                                               (2, 14, "Not very effective"),
                                                               (2, 15, "Normal"),
                                                               (2, 16, "Normal"),
                                                               (2, 17, "Super effective"),
                                                               (2, 18, "Normal"),
                                                               (3, 1, "Super effective"),
                                                               (3, 2, "Normal"),
                                                               (3, 3, "Normal"),
                                                               (3, 4, "Normal"),
                                                               (3, 5, "Not very effective"),
                                                               (3, 6, "Normal"),
                                                               (3, 7, "Not very effective"),
                                                               (3, 8, "Normal"),
                                                               (3, 9, "Normal"),
                                                               (3, 10, "Not very effective"),
                                                               (3, 11, "Super effective"),
                                                               (3, 12, "Super effective"),
                                                               (3, 13, "Not very effective"),
                                                               (3, 14, "Normal"),
                                                               (3, 15, "No effect"),
                                                               (3, 16, "Super effective"),
                                                               (3, 17, "Super effective"),
                                                               (3, 18, "Not very effective"),
                                                               (4, 1, "Normal"),
                                                               (4, 2, "Super effective"),
                                                               (4, 3, "Normal"),
                                                               (4, 4, "Not very effective"),
                                                               (4, 5, "Normal"),
                                                               (4, 6, "Not very effective"),
                                                               (4, 7, "Normal"),
                                                               (4, 8, "Normal"),
                                                               (4, 9, "Super effective"),
                                                               (4, 10, "Normal"),
                                                               (4, 11, "Super effective"),
                                                               (4, 12, "Normal"),
                                                               (4, 13, "Normal"),
                                                               (4, 14, "Not very effective"),
                                                               (4, 15, "Normal"),
                                                               (4, 16, "Normal"),
                                                               (4, 17, "Normal"),
                                                               (4, 18, "Normal"),
                                                               (5, 1, "Normal"),
                                                               (5, 2, "Normal"),
                                                               (5, 3, "Super effective"),
                                                               (5, 4, "Normal"),
                                                               (5, 5, "Normal"),
                                                               (5, 6, "Super effective"),
                                                               (5, 7, "Normal"),
                                                               (5, 8, "Not very effective"),
                                                               (5, 9, "Normal"),
                                                               (5, 10, "Normal"),
                                                               (5, 11, "Not very effective"),
                                                               (5, 12, "Normal"),
                                                               (5, 13, "Super effective"),
                                                               (5, 14, "Normal"),
                                                               (5, 15, "Normal"),
                                                               (5, 16, "Normal"),
                                                               (5, 17, "Not very effective"),
                                                               (5, 18, "Normal"),
                                                               (6, 1, "Normal"),
                                                               (6, 2, "Not very effective"),
                                                               (6, 3, "Normal"),
                                                               (6, 4, "Super effective"),
                                                               (6, 5, "Not very effective"),
                                                               (6, 6, "Not very effective"),
                                                               (6, 7, "Not very effective"),
                                                               (6, 8, "Normal"),
                                                               (6, 9, "Super effective"),
                                                               (6, 10, "Normal"),
                                                               (6, 11, "Super effective"),
                                                               (6, 12, "Normal"),
                                                               (6, 13, "Not very effective"),
                                                               (6, 14, "Not very effective"),
                                                               (6, 15, "Normal"),
                                                               (6, 16, "Normal"),
                                                               (6, 17, "Not very effective"),
                                                               (6, 18, "Normal"),
                                                               (7, 1, "Normal"),
                                                               (7, 2, "Normal"),
                                                               (7, 3, "Normal"),
                                                               (7, 4, "Normal"),
                                                               (7, 5, "Normal"),
                                                               (7, 6, "Super effective"),
                                                               (7, 7, "Not very effective"),
                                                               (7, 8, "Normal"),
                                                               (7, 9, "Not very effective"),
                                                               (7, 10, "Normal"),
                                                               (7, 11, "Not very effective"),
                                                               (7, 12, "Normal"),
                                                               (7, 13, "Normal"),
                                                               (7, 14, "Normal"),
                                                               (7, 15, "Not very effective"),
                                                               (7, 16, "Normal"),
                                                               (7, 17, "No effect"),
                                                               (7, 18, "Super effective"),
                                                               (8, 1, "Normal"),
                                                               (8, 2, "Normal"),
                                                               (8, 3, "Normal"),
                                                               (8, 4, "Super effective"),
                                                               (8, 5, "Super effective"),
                                                               (8, 6, "Not very effective"),
                                                               (8, 7, "Normal"),
                                                               (8, 8, "Not very effective"),
                                                               (8, 9, "No effect"),
                                                               (8, 10, "Normal"),
                                                               (8, 11, "Normal"),
                                                               (8, 12, "Normal"),
                                                               (8, 13, "Normal"),
                                                               (8, 14, "Not very effective"),
                                                               (8, 15, "Normal"),
                                                               (8, 16, "Normal"),
                                                               (8, 17, "Normal"),
                                                               (8, 18, "Normal"),
                                                               (9, 1, "Normal"),
                                                               (9, 2, "Super effective"),
                                                               (9, 3, "Normal"),
                                                               (9, 4, "Normal"),
                                                               (9, 5, "No effect"),
                                                               (9, 6, "Not very effective"),
                                                               (9, 7, "Super effective"),
                                                               (9, 8, "Super effective"),
                                                               (9, 9, "Normal"),
                                                               (9, 10, "Normal"),
                                                               (9, 11, "Super effective"),
                                                               (9, 12, "Normal"),
                                                               (9, 13, "Not very effective"),
                                                               (9, 14, "Normal"),
                                                               (9, 15, "Normal"),
                                                               (9, 16, "Normal"),
                                                               (9, 17, "Super effective"),
                                                               (9, 18, "Normal"),
                                                               (10, 1, "Normal"),
                                                               (10, 2, "Normal"),
                                                               (10, 3, "Super effective"),
                                                               (10, 4, "Normal"),
                                                               (10, 5, "Normal"),
                                                               (10, 6, "Normal"),
                                                               (10, 7, "Super effective"),
                                                               (10, 8, "Normal"),
                                                               (10, 9, "Normal"),
                                                               (10, 10, "Not very effective"),
                                                               (10, 11, "Normal"),
                                                               (10, 12, "Normal"),
                                                               (10, 13, "Normal"),
                                                               (10, 14, "Normal"),
                                                               (10, 15, "Normal"),
                                                               (10, 16, "No effect"),
                                                               (10, 17, "Not very effective"),
                                                               (10, 18, "Normal"),
                                                               (11, 1, "Normal"),
                                                               (11, 2, "Super effective"),
                                                               (11, 3, "Not very effective"),
                                                               (11, 4, "Normal"),
                                                               (11, 5, "Super effective"),
                                                               (11, 6, "Normal"),
                                                               (11, 7, "Normal"),
                                                               (11, 8, "Normal"),
                                                               (11, 9, "Not very effective"),
                                                               (11, 10, "Normal"),
                                                               (11, 11, "Normal"),
                                                               (11, 12, "Super effective"),
                                                               (11, 13, "Super effective"),
                                                               (11, 14, "Normal"),
                                                               (11, 15, "Normal"),
                                                               (11, 16, "Normal"),
                                                               (11, 17, "Not very effective"),
                                                               (11, 18, "Normal"),
                                                               (12, 1, "Normal"),
                                                               (12, 2, "Normal"),
                                                               (12, 3, "Normal"),
                                                               (12, 4, "Not very effective"),
                                                               (12, 5, "Super effective"),
                                                               (12, 6, "Super effective"),
                                                               (12, 7, "Normal"),
                                                               (12, 8, "Normal"),
                                                               (12, 9, "Super effective"),
                                                               (12, 10, "Normal"),
                                                               (12, 11, "Normal"),
                                                               (12, 12, "Not very effective"),
                                                               (12, 13, "Normal"),
                                                               (12, 14, "Super effective"),
                                                               (12, 15, "Normal"),
                                                               (12, 16, "Normal"),
                                                               (12, 17, "Not very effective"),
                                                               (12, 18, "Normal"),
                                                               (13, 1, "Normal"),
                                                               (13, 2, "Not very effective"),
                                                               (13, 3, "Not very effective"),
                                                               (13, 4, "Normal"),
                                                               (13, 5, "Not very effective"),
                                                               (13, 6, "Super effective"),
                                                               (13, 7, "Not very effective"),
                                                               (13, 8, "Normal"),
                                                               (13, 9, "Normal"),
                                                               (13, 10, "Super effective"),
                                                               (13, 11, "Normal"),
                                                               (13, 12, "Normal"),
                                                               (13, 13, "Normal"),
                                                               (13, 14, "Normal"),
                                                               (13, 15, "Not very effective"),
                                                               (13, 16, "Super effective"),
                                                               (13, 17, "Not very effective"),
                                                               (13, 18, "Not very effective"),
                                                               (14, 1, "Normal"),
                                                               (14, 2, "Normal"),
                                                               (14, 3, "Normal"),
                                                               (14, 4, "Normal"),
                                                               (14, 5, "Normal"),
                                                               (14, 6, "Normal"),
                                                               (14, 7, "Normal"),
                                                               (14, 8, "Normal"),
                                                               (14, 9, "Normal"),
                                                               (14, 10, "Normal"),
                                                               (14, 11, "Normal"),
                                                               (14, 12, "Normal"),
                                                               (14, 13, "Normal"),
                                                               (14, 14, "Super effective"),
                                                               (14, 15, "Normal"),
                                                               (14, 16, "Normal"),
                                                               (14, 17, "Not very effective"),
                                                               (14, 18, "No effect"),
                                                               (15, 1, "No effect"),
                                                               (15, 2, "Normal"),
                                                               (15, 3, "Normal"),
                                                               (15, 4, "Normal"),
                                                               (15, 5, "Normal"),
                                                               (15, 6, "Normal"),
                                                               (15, 7, "Normal"),
                                                               (15, 8, "Normal"),
                                                               (15, 9, "Normal"),
                                                               (15, 10, "Super effective"),
                                                               (15, 11, "Normal"),
                                                               (15, 12, "Normal"),
                                                               (15, 13, "Normal"),
                                                               (15, 14, "Normal"),
                                                               (15, 15, "Super effective"),
                                                               (15, 16, "Not very effective"),
                                                               (15, 17, "Normal"),
                                                               (15, 18, "Normal"),
                                                               (16, 1, "Normal"),
                                                               (16, 2, "Normal"),
                                                               (16, 3, "Not very effective"),
                                                               (16, 4, "Normal"),
                                                               (16, 5, "Normal"),
                                                               (16, 6, "Normal"),
                                                               (16, 7, "Normal"),
                                                               (16, 8, "Normal"),
                                                               (16, 9, "Normal"),
                                                               (16, 10, "Super effective"),
                                                               (16, 11, "Normal"),
                                                               (16, 12, "Normal"),
                                                               (16, 13, "Normal"),
                                                               (16, 14, "Normal"),
                                                               (16, 15, "Super effective"),
                                                               (16, 16, "Not very effective"),
                                                               (16, 17, "Normal"),
                                                               (16, 18, "Not very effective"),
                                                               (17, 1, "Normal"),
                                                               (17, 2, "Not very effective"),
                                                               (17, 3, "Normal"),
                                                               (17, 4, "Not very effective"),
                                                               (17, 5, "Normal"),
                                                               (17, 6, "Normal"),
                                                               (17, 7, "Normal"),
                                                               (17, 8, "Not very effective"),
                                                               (17, 9, "Normal"),
                                                               (17, 10, "Normal"),
                                                               (17, 11, "Super effective"),
                                                               (17, 12, "Super effective"),
                                                               (17, 13, "Normal"),
                                                               (17, 14, "Normal"),
                                                               (17, 15, "Normal"),
                                                               (17, 16, "Normal"),
                                                               (17, 17, "Not very effective"),
                                                               (17, 18, "Super effective"),
                                                               (18, 1, "Normal"),
                                                               (18, 2, "Not very effective"),
                                                               (18, 3, "Super effective"),
                                                               (18, 4, "Normal"),
                                                               (18, 5, "Normal"),
                                                               (18, 6, "Normal"),
                                                               (18, 7, "Not very effective"),
                                                               (18, 8, "Normal"),
                                                               (18, 9, "Normal"),
                                                               (18, 10, "Normal"),
                                                               (18, 11, "Normal"),
                                                               (18, 12, "Normal"),
                                                               (18, 13, "Normal"),
                                                               (18, 14, "Super effective"),
                                                               (18, 15, "Normal"),
                                                               (18, 16, "Super effective"),
                                                               (18, 17, "Not very effective"),
                                                               (18, 18, "Normal");
-- Insert data into WildPokemon
INSERT INTO WildPokemon (wild_id, pokemon_id, region_id, location_description, min_level, max_level) VALUES
                                                                                                         (1, 1, 7, "Lush Jungle", 18, 22),
                                                                                                         (2, 1, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (3, 1, 6, "Terminus Cave", 40, 45),
                                                                                                         (4, 2, 8, "Dusty Bowl", 30, 40),
                                                                                                         (5, 3, 2, "Slowpoke Well", 8, 14),
                                                                                                         (6, 3, 8, "Galar Mine", 12, 20),
                                                                                                         (7, 3, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (8, 4, 3, "Granite Cave", 10, 15),
                                                                                                         (9, 4, 6, "Route 7", 10, 15),
                                                                                                         (10, 4, 2, "Ilex Forest", 5, 10),
                                                                                                         (11, 5, 3, "Granite Cave", 10, 15),
                                                                                                         (12, 6, 7, "Lush Jungle", 18, 22),
                                                                                                         (13, 6, 1, "Cerulean Cave", 50, 70),
                                                                                                         (14, 7, 2, "Ilex Forest", 5, 10),
                                                                                                         (15, 7, 5, "Chargestone Cave", 20, 25),
                                                                                                         (16, 8, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (17, 8, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (18, 8, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (19, 9, 10, "South Province (Area One)", 5, 10),
                                                                                                         (20, 9, 9, "Coronet Highlands", 25, 35),
                                                                                                         (21, 9, 7, "Lush Jungle", 18, 22),
                                                                                                         (22, 10, 7, "Mount Lanakila", 40, 45),
                                                                                                         (23, 11, 4, "Mt. Coronet", 15, 25),
                                                                                                         (24, 11, 2, "Route 29", 2, 6),
                                                                                                         (25, 11, 8, "Dusty Bowl", 30, 40),
                                                                                                         (26, 12, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (27, 12, 4, "Mt. Coronet", 15, 25),
                                                                                                         (28, 12, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (29, 13, 1, "Route 1", 2, 5),
                                                                                                         (30, 13, 8, "Galar Mine", 12, 20),
                                                                                                         (31, 14, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (32, 14, 6, "Route 7", 10, 15),
                                                                                                         (33, 15, 9, "Coronet Highlands", 25, 35),
                                                                                                         (34, 16, 5, "Chargestone Cave", 20, 25),
                                                                                                         (35, 16, 2, "Slowpoke Well", 8, 14),
                                                                                                         (36, 16, 9, "Coronet Highlands", 25, 35),
                                                                                                         (37, 17, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (38, 17, 5, "Pinwheel Forest", 12, 18),
                                                                                                         (39, 18, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (40, 19, 7, "Mount Lanakila", 40, 45),
                                                                                                         (41, 20, 5, "Chargestone Cave", 20, 25),
                                                                                                         (42, 20, 8, "Galar Mine", 12, 20),
                                                                                                         (43, 20, 1, "Mt. Moon", 6, 12),
                                                                                                         (44, 21, 4, "Mt. Coronet", 15, 25),
                                                                                                         (45, 21, 7, "Mount Lanakila", 40, 45),
                                                                                                         (46, 22, 4, "Mt. Coronet", 15, 25),
                                                                                                         (47, 22, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (48, 23, 1, "Route 1", 2, 5),
                                                                                                         (49, 23, 4, "Mt. Coronet", 15, 25),
                                                                                                         (50, 23, 10, "South Province (Area One)", 5, 10),
                                                                                                         (51, 24, 1, "Rock Tunnel", 14, 20),
                                                                                                         (52, 25, 5, "Chargestone Cave", 20, 25),
                                                                                                         (53, 25, 3, "Fiery Path", 15, 20),
                                                                                                         (54, 25, 6, "Route 7", 10, 15),
                                                                                                         (55, 26, 2, "Route 29", 2, 6),
                                                                                                         (56, 26, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (57, 26, 3, "Granite Cave", 10, 15),
                                                                                                         (58, 27, 6, "Route 7", 10, 15),
                                                                                                         (59, 27, 1, "Mt. Moon", 6, 12),
                                                                                                         (60, 27, 7, "Mount Lanakila", 40, 45),
                                                                                                         (61, 28, 2, "Union Cave", 6, 12),
                                                                                                         (62, 29, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (63, 30, 8, "Dusty Bowl", 30, 40),
                                                                                                         (64, 30, 5, "Victory Road", 45, 50),
                                                                                                         (65, 30, 6, "Route 7", 10, 15),
                                                                                                         (66, 31, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (67, 32, 6, "Santalune Forest", 3, 6),
                                                                                                         (68, 33, 7, "Route 2", 5, 9),
                                                                                                         (69, 33, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (70, 34, 7, "Mount Lanakila", 40, 45),
                                                                                                         (71, 34, 6, "Santalune Forest", 3, 6),
                                                                                                         (72, 35, 7, "Lush Jungle", 18, 22),
                                                                                                         (73, 35, 6, "Santalune Forest", 3, 6),
                                                                                                         (74, 36, 2, "Union Cave", 6, 12),
                                                                                                         (75, 37, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (76, 37, 5, "Chargestone Cave", 20, 25),
                                                                                                         (77, 37, 3, "Petalburg Woods", 5, 8),
                                                                                                         (78, 38, 7, "Route 2", 5, 9),
                                                                                                         (79, 38, 4, "Mt. Coronet", 15, 25),
                                                                                                         (80, 39, 5, "Victory Road", 45, 50),
                                                                                                         (81, 39, 1, "Cerulean Cave", 50, 70),
                                                                                                         (82, 40, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (83, 40, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (84, 40, 8, "Dusty Bowl", 30, 40),
                                                                                                         (85, 41, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (86, 41, 10, "South Province (Area One)", 5, 10),
                                                                                                         (87, 42, 1, "Route 1", 2, 5),
                                                                                                         (88, 42, 9, "Coronet Highlands", 25, 35),
                                                                                                         (89, 43, 3, "Granite Cave", 10, 15),
                                                                                                         (90, 43, 4, "Eterna Forest", 8, 12),
                                                                                                         (91, 44, 10, "South Province (Area One)", 5, 10),
                                                                                                         (92, 44, 7, "Lush Jungle", 18, 22),
                                                                                                         (93, 44, 2, "Ilex Forest", 5, 10),
                                                                                                         (94, 45, 2, "Union Cave", 6, 12),
                                                                                                         (95, 45, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (96, 45, 9, "Coronet Highlands", 25, 35),
                                                                                                         (97, 46, 3, "Granite Cave", 10, 15),
                                                                                                         (98, 46, 4, "Eterna Forest", 8, 12),
                                                                                                         (99, 47, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (100, 47, 7, "Lush Jungle", 18, 22),
                                                                                                         (101, 47, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (102, 48, 1, "Cerulean Cave", 50, 70),
                                                                                                         (103, 49, 1, "Mt. Moon", 6, 12),
                                                                                                         (104, 49, 3, "Granite Cave", 10, 15),
                                                                                                         (105, 50, 8, "Galar Mine", 12, 20),
                                                                                                         (106, 51, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (107, 51, 6, "Route 7", 10, 15),
                                                                                                         (108, 52, 2, "Union Cave", 6, 12),
                                                                                                         (109, 53, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (110, 53, 4, "Mt. Coronet", 15, 25),
                                                                                                         (111, 53, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (112, 54, 1, "Rock Tunnel", 14, 20),
                                                                                                         (113, 54, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (114, 54, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (115, 55, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (116, 56, 9, "Coronet Highlands", 25, 35),
                                                                                                         (117, 57, 3, "Petalburg Woods", 5, 8),
                                                                                                         (118, 57, 1, "Route 1", 2, 5),
                                                                                                         (119, 58, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (120, 58, 6, "Terminus Cave", 40, 45),
                                                                                                         (121, 59, 5, "Victory Road", 45, 50),
                                                                                                         (122, 60, 4, "Eterna Forest", 8, 12),
                                                                                                         (123, 60, 8, "Galar Mine", 12, 20),
                                                                                                         (124, 60, 7, "Lush Jungle", 18, 22),
                                                                                                         (125, 61, 8, "Dusty Bowl", 30, 40),
                                                                                                         (126, 61, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (127, 62, 7, "Mount Lanakila", 40, 45),
                                                                                                         (128, 62, 2, "Ilex Forest", 5, 10),
                                                                                                         (129, 62, 1, "Mt. Moon", 6, 12),
                                                                                                         (130, 63, 8, "Dusty Bowl", 30, 40),
                                                                                                         (131, 64, 5, "Victory Road", 45, 50),
                                                                                                         (132, 64, 1, "Viridian Forest", 3, 7),
                                                                                                         (133, 65, 6, "Santalune Forest", 3, 6),
                                                                                                         (134, 66, 3, "Granite Cave", 10, 15),
                                                                                                         (135, 67, 10, "South Province (Area One)", 5, 10),
                                                                                                         (136, 67, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (137, 67, 7, "Mount Lanakila", 40, 45),
                                                                                                         (138, 68, 4, "Eterna Forest", 8, 12),
                                                                                                         (139, 69, 3, "Petalburg Woods", 5, 8),
                                                                                                         (140, 70, 9, "Coronet Highlands", 25, 35),
                                                                                                         (141, 70, 7, "Route 2", 5, 9),
                                                                                                         (142, 70, 10, "South Province (Area One)", 5, 10),
                                                                                                         (143, 71, 2, "Route 29", 2, 6),
                                                                                                         (144, 71, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (145, 71, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (146, 72, 3, "Fiery Path", 15, 20),
                                                                                                         (147, 72, 10, "South Province (Area One)", 5, 10),
                                                                                                         (148, 72, 4, "Eterna Forest", 8, 12),
                                                                                                         (149, 73, 2, "Route 29", 2, 6),
                                                                                                         (150, 73, 8, "Galar Mine", 12, 20),
                                                                                                         (151, 74, 1, "Mt. Moon", 6, 12),
                                                                                                         (152, 75, 5, "Victory Road", 45, 50),
                                                                                                         (153, 75, 10, "South Province (Area One)", 5, 10),
                                                                                                         (154, 76, 4, "Eterna Forest", 8, 12),
                                                                                                         (155, 76, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (156, 76, 2, "Route 29", 2, 6),
                                                                                                         (157, 77, 3, "Fiery Path", 15, 20),
                                                                                                         (158, 78, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (159, 79, 4, "Mt. Coronet", 15, 25),
                                                                                                         (160, 80, 8, "Galar Mine", 12, 20),
                                                                                                         (161, 81, 7, "Lush Jungle", 18, 22),
                                                                                                         (162, 81, 2, "Route 29", 2, 6),
                                                                                                         (163, 82, 6, "Santalune Forest", 3, 6),
                                                                                                         (164, 82, 7, "Lush Jungle", 18, 22),
                                                                                                         (165, 83, 3, "Fiery Path", 15, 20),
                                                                                                         (166, 84, 6, "Santalune Forest", 3, 6),
                                                                                                         (167, 84, 1, "Cerulean Cave", 50, 70),
                                                                                                         (168, 85, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (169, 86, 1, "Mt. Moon", 6, 12),
                                                                                                         (170, 86, 5, "Chargestone Cave", 20, 25),
                                                                                                         (171, 86, 4, "Eterna Forest", 8, 12),
                                                                                                         (172, 87, 5, "Chargestone Cave", 20, 25),
                                                                                                         (173, 88, 1, "Cerulean Cave", 50, 70),
                                                                                                         (174, 88, 4, "Mt. Coronet", 15, 25),
                                                                                                         (175, 88, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (176, 89, 3, "Petalburg Woods", 5, 8),
                                                                                                         (177, 89, 6, "Santalune Forest", 3, 6),
                                                                                                         (178, 90, 9, "Coronet Highlands", 25, 35),
                                                                                                         (179, 90, 6, "Route 7", 10, 15),
                                                                                                         (180, 91, 10, "South Province (Area One)", 5, 10),
                                                                                                         (181, 91, 7, "Lush Jungle", 18, 22),
                                                                                                         (182, 92, 6, "Santalune Forest", 3, 6),
                                                                                                         (183, 93, 1, "Viridian Forest", 3, 7),
                                                                                                         (184, 93, 6, "Terminus Cave", 40, 45),
                                                                                                         (185, 93, 8, "Galar Mine", 12, 20),
                                                                                                         (186, 94, 8, "Galar Mine", 12, 20),
                                                                                                         (187, 94, 4, "Eterna Forest", 8, 12),
                                                                                                         (188, 94, 7, "Lush Jungle", 18, 22),
                                                                                                         (189, 95, 5, "Victory Road", 45, 50),
                                                                                                         (190, 95, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (191, 96, 7, "Lush Jungle", 18, 22),
                                                                                                         (192, 97, 1, "Viridian Forest", 3, 7),
                                                                                                         (193, 97, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (194, 97, 6, "Route 7", 10, 15),
                                                                                                         (195, 98, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (196, 98, 10, "South Province (Area One)", 5, 10),
                                                                                                         (197, 99, 4, "Mt. Coronet", 15, 25),
                                                                                                         (198, 99, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (199, 100, 1, "Mt. Moon", 6, 12),
                                                                                                         (200, 100, 5, "Pinwheel Forest", 12, 18),
                                                                                                         (201, 100, 3, "Petalburg Woods", 5, 8),
                                                                                                         (202, 101, 3, "Granite Cave", 10, 15),
                                                                                                         (203, 101, 6, "Terminus Cave", 40, 45),
                                                                                                         (204, 101, 1, "Rock Tunnel", 14, 20),
                                                                                                         (205, 102, 7, "Mount Lanakila", 40, 45),
                                                                                                         (206, 102, 10, "South Province (Area One)", 5, 10),
                                                                                                         (207, 103, 5, "Pinwheel Forest", 12, 18),
                                                                                                         (208, 103, 4, "Mt. Coronet", 15, 25),
                                                                                                         (209, 103, 1, "Rock Tunnel", 14, 20),
                                                                                                         (210, 104, 8, "Galar Mine", 12, 20),
                                                                                                         (211, 105, 1, "Rock Tunnel", 14, 20),
                                                                                                         (212, 105, 9, "Coronet Highlands", 25, 35),
                                                                                                         (213, 106, 9, "Coronet Highlands", 25, 35),
                                                                                                         (214, 107, 3, "Granite Cave", 10, 15),
                                                                                                         (215, 107, 1, "Route 1", 2, 5),
                                                                                                         (216, 108, 3, "Granite Cave", 10, 15),
                                                                                                         (217, 109, 5, "Victory Road", 45, 50),
                                                                                                         (218, 109, 10, "South Province (Area One)", 5, 10),
                                                                                                         (219, 109, 1, "Rock Tunnel", 14, 20),
                                                                                                         (220, 110, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (221, 110, 4, "Mt. Coronet", 15, 25),
                                                                                                         (222, 111, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (223, 111, 6, "Terminus Cave", 40, 45),
                                                                                                         (224, 112, 10, "South Province (Area One)", 5, 10),
                                                                                                         (225, 112, 3, "Granite Cave", 10, 15),
                                                                                                         (226, 113, 4, "Mt. Coronet", 15, 25),
                                                                                                         (227, 113, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (228, 114, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (229, 114, 5, "Pinwheel Forest", 12, 18),
                                                                                                         (230, 114, 10, "South Province (Area One)", 5, 10),
                                                                                                         (231, 115, 7, "Mount Lanakila", 40, 45),
                                                                                                         (232, 115, 1, "Route 1", 2, 5),
                                                                                                         (233, 116, 1, "Cerulean Cave", 50, 70),
                                                                                                         (234, 116, 7, "Mount Lanakila", 40, 45),
                                                                                                         (235, 117, 8, "Galar Mine", 12, 20),
                                                                                                         (236, 118, 6, "Santalune Forest", 3, 6),
                                                                                                         (237, 118, 4, "Mt. Coronet", 15, 25),
                                                                                                         (238, 119, 9, "Coronet Highlands", 25, 35),
                                                                                                         (239, 119, 3, "Fiery Path", 15, 20),
                                                                                                         (240, 119, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (241, 120, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (242, 121, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (243, 121, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (244, 121, 2, "Slowpoke Well", 8, 14),
                                                                                                         (245, 122, 5, "Chargestone Cave", 20, 25),
                                                                                                         (246, 122, 6, "Terminus Cave", 40, 45),
                                                                                                         (247, 123, 6, "Santalune Forest", 3, 6),
                                                                                                         (248, 124, 2, "Ilex Forest", 5, 10),
                                                                                                         (249, 124, 8, "Galar Mine", 12, 20),
                                                                                                         (250, 125, 9, "Coronet Highlands", 25, 35),
                                                                                                         (251, 126, 5, "Pinwheel Forest", 12, 18),
                                                                                                         (252, 126, 4, "Mt. Coronet", 15, 25),
                                                                                                         (253, 127, 3, "Granite Cave", 10, 15),
                                                                                                         (254, 127, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (255, 128, 2, "Ilex Forest", 5, 10),
                                                                                                         (256, 128, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (257, 128, 5, "Pinwheel Forest", 12, 18),
                                                                                                         (258, 129, 5, "Victory Road", 45, 50),
                                                                                                         (259, 129, 8, "Galar Mine", 12, 20),
                                                                                                         (260, 130, 2, "Union Cave", 6, 12),
                                                                                                         (261, 131, 8, "Galar Mine", 12, 20),
                                                                                                         (262, 132, 7, "Mount Lanakila", 40, 45),
                                                                                                         (263, 132, 10, "South Province (Area One)", 5, 10),
                                                                                                         (264, 133, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (265, 133, 5, "Victory Road", 45, 50),
                                                                                                         (266, 133, 1, "Cerulean Cave", 50, 70),
                                                                                                         (267, 134, 7, "Lush Jungle", 18, 22),
                                                                                                         (268, 134, 8, "Motostoke Outskirts", 10, 15),
                                                                                                         (269, 134, 9, "Coronet Highlands", 25, 35),
                                                                                                         (270, 135, 7, "Route 2", 5, 9),
                                                                                                         (271, 135, 10, "South Province (Area One)", 5, 10),
                                                                                                         (272, 135, 2, "Slowpoke Well", 8, 14),
                                                                                                         (273, 136, 6, "Santalune Forest", 3, 6),
                                                                                                         (274, 136, 3, "Fiery Path", 15, 20),
                                                                                                         (275, 136, 2, "Ilex Forest", 5, 10),
                                                                                                         (276, 137, 9, "Coronet Highlands", 25, 35),
                                                                                                         (277, 137, 8, "Dusty Bowl", 30, 40),
                                                                                                         (278, 138, 2, "Slowpoke Well", 8, 14),
                                                                                                         (279, 138, 6, "Santalune Forest", 3, 6),
                                                                                                         (280, 138, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (281, 139, 5, "Pinwheel Forest", 12, 18),
                                                                                                         (282, 140, 2, "Ilex Forest", 5, 10),
                                                                                                         (283, 140, 7, "Route 2", 5, 9),
                                                                                                         (284, 141, 6, "Terminus Cave", 40, 45),
                                                                                                         (285, 141, 10, "West Province (Area Three)", 25, 30),
                                                                                                         (286, 142, 4, "Mt. Coronet", 15, 25),
                                                                                                         (287, 142, 3, "Granite Cave", 10, 15),
                                                                                                         (288, 142, 2, "Route 29", 2, 6),
                                                                                                         (289, 143, 3, "Petalburg Woods", 5, 8),
                                                                                                         (290, 144, 9, "Obsidian Fieldlands", 5, 15),
                                                                                                         (291, 144, 10, "South Province (Area One)", 5, 10),
                                                                                                         (292, 145, 3, "Granite Cave", 10, 15),
                                                                                                         (293, 145, 5, "Victory Road", 45, 50),
                                                                                                         (294, 146, 1, "Route 1", 2, 5),
                                                                                                         (295, 146, 2, "Ilex Forest", 5, 10),
                                                                                                         (296, 147, 5, "Victory Road", 45, 50),
                                                                                                         (297, 148, 8, "Galar Mine", 12, 20),
                                                                                                         (298, 149, 9, "Coronet Highlands", 25, 35),
                                                                                                         (299, 149, 4, "Oreburgh Gate", 5, 9),
                                                                                                         (300, 149, 6, "Terminus Cave", 40, 45),
                                                                                                         (301, 150, 5, "Pinwheel Forest", 12, 18),
                                                                                                         (302, 150, 4, "Eterna Forest", 8, 12),
                                                                                                         (303, 151, 1, "Rock Tunnel", 14, 20),
                                                                                                         (304, 150, 1, "Cerulean Cave", 70, 70),
                                                                                                         (305, 151, 1, "Faraway Island", 30, 30);
-- Create a table to log all deleted trainers
CREATE TABLE DeletedTrainers (
                                 LogID INT PRIMARY KEY AUTO_INCREMENT,
                                 TrainerID INT,
                                 Name VARCHAR(50),
                                 Action VARCHAR(20),
                                 DeletedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Log deleted trainer after delete
DELIMITER $$

CREATE TRIGGER after_trainer_delete
    AFTER DELETE ON Trainer
    FOR EACH ROW
BEGIN
    INSERT INTO DeletedTrainers (TrainerID, Name, Action)
    VALUES (OLD.trainer_id, OLD.name, 'deleted');

END$$
DELIMITER ;


-- Delete trainer pokemon before trainer
DELIMITER $$

CREATE TRIGGER delete_trainer_pokemon
    BEFORE DELETE ON Trainer
    FOR EACH ROW
BEGIN
    DELETE FROM TrainerPokemon
    WHERE trainer_id = OLD.trainer_id;

END $$
DELIMITER ;


-- Change gym leader if the current leader gets deleted
DELIMITER $$

CREATE TRIGGER change_leader_if_deleted
    BEFORE DELETE ON Trainer
    FOR EACH ROW
BEGIN
    DECLARE new_leader INT;

    -- If the deleted player is NOT trainer 4:
    IF OLD.trainer_id <> 4 THEN
        -- Reassign their gyms to trainer 4
        UPDATE Gym
        SET leader_id = 4
        WHERE leader_id = OLD.trainer_id;

        -- Else select the next available trainer
    ELSE
        SELECT trainer_id
        INTO new_leader
        FROM Trainer
        WHERE trainer_id <> OLD.trainer_id
        ORDER BY trainer_id
        LIMIT 1;

        -- Update gym leader to the next available leader
        IF new_leader IS NOT NULL THEN
            UPDATE Gym
            SET leader_id = new_leader
            WHERE leader_id = OLD.trainer_id;
        END IF;
    END IF;

END $$
DELIMITER ;


-- Automatically adjust pokemon level to stay within valid bounds (between 1 and 100)
DELIMITER $$

CREATE TRIGGER check_pokemon_level
    BEFORE INSERT ON TrainerPokemon
    FOR EACH ROW
BEGIN
    -- If level less than 1, set it to 1
    IF NEW.pokemon_level < 1 THEN
        SET NEW.pokemon_level = 1;
    END IF;

    -- If level greater than 100, set it to 100
    IF NEW.pokemon_level > 100 THEN
        SET NEW.pokemon_level = 100;
    END IF;
END$$

DELIMITER ;

-- Cap caught pokemon max IVs
DELIMITER $$

create trigger cap_max_iv
    before insert on TrainerPokemon
    for each row
begin
    -- Check if each IV is lower than 31 and change it to 31 otherwise
    if NEW.hit_points_iv > 31 then
        set new.hit_points_iv = 31;
    end if;
    if NEW.attack_iv > 31 then
        set new.attack_iv = 31;
    end if;
    if NEW.defense_iv > 31 then
        set new.defense_iv = 31;
    end if;
end;

DELIMITER ;


-- Because of constraints Delete statements can only be run properly with triggers present

-- Update pokemon level by 1 for each pokemon with trainer_id = 4
-- Can be used when pokemon gains a level after a fight 
UPDATE TrainerPokemon AS tp
SET tp.pokemon_level = tp.pokemon_level + 1
WHERE tp.trainer_id = 4;

-- Delete all of trainer 6's pokemon
-- Can be used when Trainer 6 npc gets defeated and is no longer needed
DELETE FROM TrainerPokemon
WHERE trainer_id = 6;

-- Update a pokemons base hp
UPDATE Pokemon
SET base_hp=46
where pokemon_id=1;

-- View that calculates stats for each caught pokemon based on their base stats and IVs
CREATE VIEW TrainerPokemonStats AS
SELECT
    tp.caught_id,
    tp.trainer_id,
    tp.nick_name AS Name,
    p.name AS Species,
    tp.pokemon_level as Level,

    -- Calculated HP
    FLOOR(((p.base_hp + tp.hit_points_iv) * 2 * tp.pokemon_level) / 100) + tp.pokemon_level + 10 AS HP,

    -- Calculated Attack
    FLOOR(((p.base_attack + tp.attack_iv) * 2 * tp.pokemon_level) / 100) + 5 AS Attack,

    -- Calculated Defense
    FLOOR(((p.base_defense + tp.defense_iv) * 2 * tp.pokemon_level) / 100) + 5 AS Defense

FROM TrainerPokemon tp
         JOIN Pokemon p ON tp.pokemon_id = p.pokemon_id;

-- View: Displays each Pokemon with all of its types combined into one line
CREATE VIEW PokemonWithTypes AS
SELECT
    p.pokemon_id,
    p.name,
    GROUP_CONCAT(t.type_name ORDER BY t.type_name SEPARATOR '/') AS types
FROM Pokemon AS p
         LEFT JOIN PokemonTypes AS pt ON pt.pokemon_id = p.pokemon_id
         LEFT JOIN Types AS t         ON t.type_id = pt.type_id
GROUP BY p.pokemon_id, p.name;

-- View: Displays trainer details with total pokemon, if there a gym leader and there location
CREATE VIEW TrainerSummary AS
SELECT
    tr.trainer_id,
    tr.name AS TrainerName,
    tr.gender,
    tr.age,

-- Get amount of pokemon owned
    COUNT(tp.pokemon_id) AS TotalPokemon,
    -- Check if trainer is a gym leader
    CASE
        WHEN g.leader_id IS NOT NULL THEN 'Yes'
        ELSE 'No'
        END AS IsGymLeader,
    twn.name AS HomeTown,
    r.name AS Region,
    gt.name AS GymTown,
    ty.type_name AS GymType
FROM Trainer AS tr
         LEFT JOIN TrainerPokemon AS tp ON tr.trainer_id = tp.trainer_id
         LEFT JOIN Gym AS g ON tr.trainer_id = g.leader_id
         LEFT JOIN Town AS gt ON g.town_id = gt.town_id
         LEFT JOIN Types AS ty ON g.type_id = ty.type_id
         JOIN Town AS twn ON tr.home_town_id = twn.town_id
         JOIN Region AS r ON twn.region_id = r.region_id
GROUP BY tr.trainer_id, tr.name, tr.gender, tr.age, g.leader_id, twn.name, r.name, gt.name, ty.type_name;

-- A stored procedures used to trade pokemon which has a transaction that rollsback if an error occurs and commits otherwise
-- Can be tested running:
-- CALL TradePokemon(1, 1, 8, 4);
-- twice

DELIMITER $$

-- Create procedure to trade pokemon
CREATE PROCEDURE TradePokemon(
    IN p1_id INT,
    IN t1_id INT,
    IN p2_id INT,
    IN t2_id INT
)
BEGIN
    -- declare variables to check how many rows get effected
    DECLARE rows1 INT DEFAULT 0;
    DECLARE rows2 INT DEFAULT 0;

-- check if sqlexception occurs
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SELECT 'Trade failed, rolled back' AS status;
        END;

    START TRANSACTION;

    -- Transfer Pokemon 1 to trainer 2 and set amount of rows affected
    UPDATE TrainerPokemon
    SET trainer_id = t2_id
    WHERE caught_id = p1_id AND trainer_id = t1_id;
    SET rows1 = ROW_COUNT();

    --  Transfer Pokemon 2 to trainer 1 and set amount of rows affected
    UPDATE TrainerPokemon
    SET trainer_id = t1_id
    WHERE caught_id = p2_id AND trainer_id = t2_id;
    SET rows2 = ROW_COUNT();

    -- Check if both updates affected exactly 1 row and commit else rollback
    IF rows1 = 1 AND rows2 = 1 THEN
        COMMIT;
        SELECT 'Trade successful' AS status;
    ELSE
        ROLLBACK;
        SELECT 'Trade failed, rolled back' AS status;
    END IF;
END$$

DELIMITER ;



-- A stored procedure used to simulate buying a wild pokemon by a trainer
-- Rolls back if any insert/update fails
-- Example test:
-- CALL BuyPokemon(1, 1, 5, 25, 12, 10, 10, 10);

DELIMITER $$

CREATE PROCEDURE BuyPokemon(
    IN wild_pokemon_id INT,  -- ID in WildPokemon
    IN trainer_id INT,       -- trainer who buys
    IN pokemon_level INT,
    IN hit_iv INT,
    IN atk_iv INT,
    IN def_iv INT
)
BEGIN
    DECLARE pkmn_id INT;
    DECLARE pkmn_name VARCHAR(50);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SELECT 'Purchase failed, rolled back' AS status;
        END;

    START TRANSACTION;

    -- Get pokemon ID and name from WildPokemon
    SELECT wp.pokemon_id, p.name
    INTO pkmn_id, pkmn_name
    FROM WildPokemon AS wp
             JOIN Pokemon AS p ON wp.pokemon_id = p.pokemon_id
    WHERE wp.wild_id = wild_pokemon_id;

    -- Insert into TrainerPokemon table (trainer now owns it)
    INSERT INTO TrainerPokemon(trainer_id, pokemon_id, nick_name, pokemon_level, hit_points_iv, attack_iv, defense_iv)
    VALUES (trainer_id, pkmn_id, pkmn_name, pokemon_level, hit_iv, atk_iv, def_iv);

    -- Remove from WildPokemon (caught)
    DELETE FROM WildPokemon WHERE wild_id = wild_pokemon_id;

    COMMIT;
    SELECT CONCAT('Trainer ', trainer_id, ' successfully bought ', pkmn_name) AS status;
END$$

DELIMITER ;

-- Procedure used to add a new pokemon
DELIMITER $$

CREATE PROCEDURE AddPokemon(IN species_name VARCHAR(50), IN baseHP INT, IN baseAttack INT, IN baseDefense INT, IN type1ID INT, IN type2ID INT, IN regionID INT, IN locationDescription VARCHAR(50), IN minLevel INT, IN maxLevel INT)
BEGIN
    -- Declare a variable to store new pokemon ID
    DECLARE new_pokemon_id INT;

    -- Insert data into pokemon
    INSERT INTO Pokemon(name, base_hp, base_attack, base_defense)
    VALUES (species_name, baseHP, baseAttack, baseDefense);

    -- Set last inserted ID as new pokemon ID
    SET new_pokemon_id = LAST_INSERT_ID();

    -- Insert data into wildpokemon using new ID
    INSERT INTO WildPokemon(pokemon_id, region_id, location_description, min_level, max_level)
    VALUES (new_pokemon_id, regionID, locationDescription, minLevel, maxLevel);

    -- Insert first type
    INSERT INTO PokemonTypes(pokemon_id, type_id)
    VALUES (new_pokemon_id, type1ID);

    -- Insert second type if exists
    IF type2ID IS NOT NULL THEN
        INSERT INTO PokemonTypes(pokemon_id, type_id)
        VALUES (new_pokemon_id, type2ID);
    END IF;
END$$

DELIMITER ;


-- Procedure used to add a new trainer with a starter pokemon
DELIMITER $$

CREATE PROCEDURE AddTrainerWithStarter(
    IN trainerName VARCHAR(50),
    IN homeTownID INT,
    IN starterPokemonID INT,
    IN nickname VARCHAR(50),
    IN starterLevel INT
)
BEGIN
    -- Get random Ivs
    DECLARE new_trainer_id INT;
    DECLARE hp_iv INT DEFAULT FLOOR(RAND() * 31);
    DECLARE atk_iv INT DEFAULT FLOOR(RAND() * 31);
    DECLARE def_iv INT DEFAULT FLOOR(RAND() * 31);

    -- Insert trainer into Trainer table
    INSERT INTO Trainer (home_town_id, name, gender, age)
    VALUES (homeTownID, trainerName, gender, age);

    -- Store last inserted trainer id
    SET new_trainer_id = LAST_INSERT_ID();

    -- Insert starter pokemon into TrainerPokemon
    INSERT INTO TrainerPokemon (trainer_id, pokemon_id, nick_name, pokemon_level, hit_points_iv, attack_iv, defense_iv)
    VALUES (new_trainer_id, starterPokemonID, nickname, starterLevel, hp_iv, atk_iv, def_iv);

    -- Return confirmation
    SELECT CONCAT('Trainer ', trainerName, ' added with starter Pokemon ID ', starterPokemonID) AS status;
END$$

DELIMITER ;
-- Index for the region join
CREATE INDEX index_wildpokemon_region ON WildPokemon(region_id);

-- Index for the pokemon join
CREATE INDEX index_wildpokemon_pokemon ON WildPokemon(pokemon_id);

-- Index for PokemonTypes join (frequent joins between Pokemon and Types)
CREATE INDEX idx_pokemontypes_pokemon_id ON PokemonTypes(pokemon_id);
CREATE INDEX idx_pokemontypes_type_id ON PokemonTypes(type_id);

-- To show indexes being used run
EXPLAIN
SELECT
    p.name AS pokemon_name,
    r.name AS region,
    w.location_description,
    w.min_level,
    w.max_level
FROM WildPokemon AS w
         JOIN Region AS r ON w.region_id = r.region_id
         JOIN Pokemon AS p ON w.pokemon_id = p.pokemon_id;
CREATE USER 'pokemon_app'@'localhost' IDENTIFIED BY 'Strong_Pass123!';
CREATE USER 'pokemon_app'@'%' IDENTIFIED BY 'Strong_Pass123!';
CREATE USER 'pokemon_readonly'@'localhost' IDENTIFIED BY 'ReadOnly_Pass123!';
CREATE USER 'pokemon_admin'@'localhost' IDENTIFIED BY 'Admin_Pass123!';
CREATE USER 'trainer_user'@'localhost' IDENTIFIED BY 'Trainer_Pass123!';

GRANT ALL PRIVILEGES ON Pokemon.* TO 'pokemon_admin'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON Pokemon.* TO 'pokemon_app'@'localhost';
GRANT SELECT, INSERT ON Pokemon.TrainerPokemon TO 'trainer_user'@'localhost';
GRANT SELECT ON Pokemon.Pokemon TO 'trainer_user'@'localhost';
GRANT SELECT ON Pokemon.Types TO 'trainer_user'@'localhost';
GRANT SELECT ON Pokemon.* TO 'pokemon_readonly'@'localhost';

FLUSH PRIVILEGES;

SHOW GRANTS FOR 'pokemon_app'@'localhost';
SHOW GRANTS FOR 'pokemon_readonly'@'localhost';
SHOW GRANTS FOR 'trainer_user'@'localhost';

GRANT UPDATE ON Pokemon.TrainerPokemon TO 'trainer_user'@'localhost';
FLUSH PRIVILEGES;

REVOKE INSERT ON Pokemon.TrainerPokemon FROM 'trainer_user'@'localhost';

FLUSH PRIVILEGES;

ALTER USER 'pokemon_app'@'localhost' IDENTIFIED BY 'NewPassword123!';

DROP USER 'pokemon_app'@'localhost', 'pokemon_readonly'@'localhost';

CREATE USER 'pokemon_app'@'localhost' IDENTIFIED BY 'App_Pass123!';
GRANT SELECT, INSERT, UPDATE, DELETE ON Pokemon.* TO 'pokemon_app'@'localhost';
FLUSH PRIVILEGES;

CREATE USER 'pokemon_readonly'@'localhost' IDENTIFIED BY 'Read_Pass123!';
GRANT SELECT ON Pokemon.* TO 'pokemon_readonly'@'localhost';
FLUSH PRIVILEGES;

CREATE USER 'pokemon_trainer'@'localhost' IDENTIFIED BY 'Trainer_Pass123!';
GRANT SELECT ON Pokemon.Pokemon TO 'pokemon_trainer'@'localhost';
GRANT SELECT ON Pokemon.Gym TO 'pokemon_trainer'@'localhost';
GRANT SELECT ON Pokemon.Types TO 'pokemon_trainer'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON Pokemon.TrainerPokemon TO 'pokemon_trainer'@'localhost';
GRANT SELECT, INSERT, UPDATE ON Pokemon.Trainer TO 'pokemon_trainer'@'localhost';
FLUSH PRIVILEGES;

SELECT user, host,
       Select_priv, Insert_priv, Update_priv, Delete_priv
FROM mysql.user
WHERE user IN ('pokemon_app', 'pokemon_readonly', 'pokemon_trainer');

SELECT * FROM mysql.tables_priv
WHERE Db = 'Pokemon';


DROP USER IF EXISTS 'pokemon_app'@'localhost';
DROP USER IF EXISTS 'pokemon_app'@'%';
DROP USER IF EXISTS 'pokemon_readonly'@'localhost';
DROP USER IF EXISTS 'pokemon_admin'@'localhost';
DROP USER IF EXISTS 'pokemon_trainer'@'localhost';
DROP USER IF EXISTS 'trainer_user'@'localhost';

SELECT user, host FROM mysql.user;

-- Select all pokemon, and their types
SELECT p.name, t.type_name
FROM Pokemon AS p
         LEFT JOIN PokemonTypes AS pt ON p.pokemon_id = pt.pokemon_id
         LEFT JOIN Types AS t ON t.type_id = pt.type_id
WHERE t.type_name = 'Normal';

-- Show trainers and the Pokémon they own
SELECT
    tr.name AS Trainer,
    tr.gender,
    tr.age,
    p.name AS Pokemon,
    tp.nick_name AS Nickname,
    tp.pokemon_level AS Level
FROM TrainerPokemon AS tp
         JOIN Trainer AS tr ON tp.trainer_id = tr.trainer_id
         JOIN Pokemon AS p ON tp.pokemon_id = p.pokemon_id
ORDER BY tr.name;

-- Show all gym leaders and their pokemon
SELECT
    tr.name AS Trainer,
    g.gym_id AS Gym,
    p.name AS Pokemon,
    tp.pokemon_level AS Level
FROM Trainer AS tr
         JOIN TrainerPokemon As tp ON tr.trainer_id = tp.trainer_id
         JOIN Gym as g on g.leader_id = tr.trainer_id
         JOIN Pokemon AS p on tp.pokemon_id = p.pokemon_id
order by g.gym_id, tr.name;
